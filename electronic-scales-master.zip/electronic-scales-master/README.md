# version 1: connect electronic scalesr to printer

## Install
```
sudo apt-get -y install python3-pip
sudo apt-get -y install python3-tk
pip3 install rsa
pip3 install pyserial
pip3 install python-dotenv
pip3 install netifaces
```

## Add service file
```
sudo nano /lib/systemd/system/prg.service
```

Content
```
[Unit]
Description=Connect electronic scalesr to printer
After=multi-user.target

[Service]
Environment=DISPLAY=:0
Environment=XAUTHORITY=/home/hoanghoi/.Xauthority
ExecStart=/usr/bin/python3 -u PrinterForm.py
WorkingDirectory=/home/hoanghoi/prg/frontend
Restart=always
RestartSec=5s
KillMode=process
User=hoanghoi

[Install]
WantedBy=graphical.target
```

### Start on startup
```
sudo systemctl enable prg.service
```

### Start service
```
sudo systemctl start prg.service
```

### Status service
```
sudo systemctl status prg.service
```

## Add desktop
```
nano ~/Desktop/ElectronicScale.desktop
```

Content
```
#!/usr/bin/env xdg-open
[Desktop Entry]
Version=1.0
Type=Application
Terminal=false
Exec=/usr/bin/python3 -u PrinterForm.py
Path=/home/hoanghoi/prg/frontend
Name=ElectronicScale
Comment=ElectronicScale
Icon=/home/hoanghoi/prg/frontend/logo.jpg
```

## Fix ssh
```
sudo ssh-keygen -t rsa -f /etc/ssh/ssh_host_rsa_key
sudo ssh-keygen -t ecdsa -f /etc/ssh/ssh_host_ecdsa_key
sudo ssh-keygen -t ed25519 -f /etc/ssh/ssh_host_ed25519_key
```

## Tar gz file
### Compress folder
```
tar -czvf archive.tar.gz /path/to/directory-or-file
```

### Extract an Archive
```
tar -xzvf archive.tar.gz
```

## Change swap site raspbian OS
Change the size in file `/etc/dphys-swapfile`
```
sudo nano /etc/dphys-swapfile
```

Change
```
CONF_SWAPFILE=1024
```

## Fix permission when connect serial port

```
sudo usermod -aG dialout user
```
