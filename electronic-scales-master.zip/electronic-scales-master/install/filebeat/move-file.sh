#!/bin/bash
set -e

cd ${GOPATH}/src/github.com/elastic/beats/filebeat
chmod go-w filebeat.yml
sudo rm -rf /usr/share/filebeat /usr/share/filebeat/bin /etc/filebeat /var/log/filebeat /var/lib/filebeat
sudo mkdir /usr/share/filebeat /usr/share/filebeat/bin /etc/filebeat /var/log/filebeat /var/lib/filebeat
sudo cp -R filebeat /usr/share/filebeat/bin
sudo cp -R module /usr/share/filebeat/
sudo cp -R modules.d/ /etc/filebeat/
sudo cp -R filebeat.yml /etc/filebeat/
sudo chown -R root:root /usr/share/filebeat/*
sudo chown -R root:root /etc/filebeat/*
sudo chmod 755 /var/log/filebeat
sudo chmod 755 /etc/filebeat/
