#!/bin/bash
set -e
cd ~
sudo apt-get -y install python-pip git
sudo pip install virtualenv

wget https://dl.google.com/go/go1.12.7.linux-armv6l.tar.gz
sudo rm -rf /usr/local/go
sudo tar -C /usr/local -xzf go1.12.7.linux-armv6l.tar.gz
sudo chown $USER:$USER -R /usr/local/go

# echo "\n# go lang" >> ~/.zshrc
# echo "export PATH=\$PATH:/usr/local/go/bin" >> ~/.zshrc
# echo "export GOPATH=\$HOME/go" >> ~/.zshrc
# echo "export PATH=\"\$GOPATH/bin:\$PATH\"" >> ~/.zshrc

export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go
export PATH="$GOPATH/bin:$PATH"

mkdir -p ${GOPATH}/src/github.com/elastic
go get github.com/magefile/mage
cd ${GOPATH}/src/github.com/elastic
git clone https://github.com/elastic/beats.git
cd beats/
git checkout v7.1.0
cd filebeat/
make
go build -i
