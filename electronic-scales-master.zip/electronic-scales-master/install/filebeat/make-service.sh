#!/bin/bash
set -e

sudo rm -rf /lib/systemd/system/filebeat.Service
sudo bash -c 'echo "[Unit]" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Description=filebeat" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Documentation=https://www.elastic.co/guide/en/beats/filebeat/current/index.html" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Wants=userwork-online.target" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "After=network-online.target" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "[Service]" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "ExecStart=/usr/share/filebeat/bin/filebeat -c /etc/filebeat/filebeat.yml -path.home /usr/share/filebeat -path.config /etc/filebeat -path.data /var/lib/filebeat -path.logs /var/log/filebeat" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Restart=always" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "[Install]" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "WantedBy=multi-user.target" >> /lib/systemd/system/filebeat.service'
