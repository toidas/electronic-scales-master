#!/bin/bash
set -e
cd ~
sudo apt-get -y install python-pip git
sudo pip install virtualenv

wget https://dl.google.com/go/go1.12.7.linux-armv6l.tar.gz
sudo rm -rf /usr/local/go
sudo tar -C /usr/local -xzf go1.12.7.linux-armv6l.tar.gz
sudo chown $USER:$USER -R /usr/local/go

# echo "\n# go lang" >> ~/.zshrc
# echo "export PATH=\$PATH:/usr/local/go/bin" >> ~/.zshrc
# echo "export GOPATH=\$HOME/go" >> ~/.zshrc
# echo "export PATH=\"\$GOPATH/bin:\$PATH\"" >> ~/.zshrc

export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go
export PATH="$GOPATH/bin:$PATH"

mkdir -p ${GOPATH}/src/github.com/elastic
go get github.com/magefile/mage
cd ${GOPATH}/src/github.com/elastic
git clone https://github.com/elastic/beats.git
cd beats/
git checkout v7.1.0
cd filebeat/
make
go build -i

chmod go-w filebeat.yml
sudo chown $USER:$USER -R /usr/local/go
sudo mkdir /usr/share/filebeat /usr/share/filebeat/bin /etc/filebeat /var/log/filebeat /var/lib/filebeat
sudo mv filebeat /usr/share/filebeat/bin
sudo mv module /usr/share/filebeat/
sudo mv modules.d/ /etc/filebeat/
sudo cp filebeat.yml /etc/filebeat/
sudo chown -R root:root /usr/share/filebeat/*
sudo chown -R root:root /etc/filebeat/*
sudo chmod 755 /var/log/filebeat
sudo chmod 755 /etc/filebeat/

sudo rm -rf /lib/systemd/system/filebeat.Service
sudo bash -c 'echo "[Unit]" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Description=filebeat" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Documentation=https://www.elastic.co/guide/en/beats/filebeat/current/index.html" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Wants=userwork-online.target" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "After=network-online.target" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "[Service]" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "ExecStart=/usr/share/filebeat/bin/filebeat -c /etc/filebeat/filebeat.yml -path.home /usr/share/filebeat -path.config /etc/filebeat -path.data /var/lib/filebeat -path.logs /var/log/filebeat" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "Restart=always" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "[Install]" >> /lib/systemd/system/filebeat.service'
sudo bash -c 'echo "WantedBy=multi-user.target" >> /lib/systemd/system/filebeat.service'

sudo systemctl enable filebeat
sudo service filebeat start
