#!/bin/bash
set -e

sudo swapon --show
free -h
df -h
sudo swapoff -a
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
ls -lh /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
sudo swapon --show
free -h
