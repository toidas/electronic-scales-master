#!/bin/bash
sudo apt-get -y install python3-pip
sudo apt-get -y install python3-tk
pip3 install rsa
pip3 install pyserial
pip3 install python-dotenv
pip3 install netifaces
