#!/bin/bash
set -e
hash=$(ls)
echo $hash
