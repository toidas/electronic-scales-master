# Initial Dependencies
```
user@raspberrypi:~ $ sudo apt-get install python-pip git
user@raspberrypi:~ $ sudo pip install virtualenv
```

# Installing Go
Download ARMv6 architecture version
[https://golang.org/dl](https://golang.org/dl)

Current version is 1.12.7
[https://dl.google.com/go/go1.12.7.linux-armv6l.tar.gz](https://dl.google.com/go/go1.12.7.linux-armv6l.tar.gz)
```
user@raspberrypi:~ $ wget https://dl.google.com/go/go1.12.7.linux-armv6l.tar.gz
user@raspberrypi:~ $ sudo tar -C /usr/local -xzf go1.12.7.linux-armv6l.tar.gz
user@raspberrypi:~ $ export PATH=$PATH:/usr/local/go/bin
user@raspberrypi:~ $ go version
```

Add `PATH=$PATH:/usr/local/go/bin` to the `~/.profile` or `~/.bash_profile` or `~/.zshrc`

# Downloading & Building filebeat
```
user@raspberrypi:~ $ export GOPATH=$HOME/go
user@raspberrypi:~ $ export PATH="$GOPATH/bin:$PATH"
user@raspberrypi:~ $ mkdir go
user@raspberrypi:~ $ mkdir -p ${GOPATH}/src/github.com/elastic
user@raspberrypi:~ $ go get github.com/magefile/mage
user@raspberrypi:~ $ cd ${GOPATH}/src/github.com/elastic
user@raspberrypi:~/go/src/github.com/elastic $ git clone https://github.com/elastic/beats.git
user@raspberrypi:~/go/src/github.com/elastic $ cd beats/
user@raspberrypi:~/go/src/github.com/elastic/beats $ git checkout v7.1.0
user@raspberrypi:~/go/src/github.com/elastic/beats $ cd filebeat/
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ make
go build -i
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ make update
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ chmod go-w filebeat.yml
```

- Có thể không chạy `make update`
- Nếu chạy bị lỗi permission thì chạy lệnh
```
user@raspberrypi:~ $ sudo chown $USER:$USER -R /usr/local/go
```

# Use
```
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ ./filebeat -e -v
```

# Create service
```
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo mkdir /usr/share/filebeat /usr/share/filebeat/bin /etc/filebeat /var/log/filebeat /var/lib/filebeat
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo mv filebeat /usr/share/filebeat/bin
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo mv module /usr/share/filebeat/
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo mv modules.d/ /etc/filebeat/
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo cp filebeat.yml /etc/filebeat/
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo chmod 750 /var/log/filebeat
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo chmod 750 /etc/filebeat/
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo chown -R root:root /usr/share/filebeat/*
user@raspberrypi:~/go/src/github.com/elastic/beats/filebeat $ sudo chown -R root:root /etc/filebeat/*
```

```
sudo nano /lib/systemd/system/filebeat.service
```

Add content
```
[Unit]
Description=filebeat
Documentation=https://www.elastic.co/guide/en/beats/filebeat/current/index.html
Wants=userwork-online.target
After=network-online.target

[Service]
ExecStart=/usr/share/filebeat/bin/filebeat -c /etc/filebeat/filebeat.yml -path.home /usr/share/filebeat -path.config /etc/filebeat -path.data /var/lib/filebeat -path.logs /var/log/filebeat
Restart=always

[Install]
WantedBy=multi-user.target
```

Start on startup
```
sudo systemctl enable filebeat
```

Start service
```
sudo service filebeat start
```

Status service
```
sudo service filebeat status
```
