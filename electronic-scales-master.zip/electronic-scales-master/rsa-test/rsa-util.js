const fs = require("fs");
const NodeRSA = require("node-rsa");

function generateKeyPair() {
  const key = new NodeRSA();
  const keyPair = key.generateKeyPair(512);
  const publicKeyData = keyPair.exportKey("pkcs1-public-pem");
  fs.writeFileSync("public.pem", publicKeyData);
  const privateKeyData = keyPair.exportKey("pkcs1-private-pem");
  fs.writeFileSync("private.pem", privateKeyData);
}
generateKeyPair();

const publicKey = new NodeRSA();
const publicKeyData = fs.readFileSync("public.pem");
publicKey.importKey(publicKeyData);

const privateKey = new NodeRSA();
const privateKeyData = fs.readFileSync("private.pem");
privateKey.importKey(privateKeyData);

function verify(clientPublicKeyData, data, signature) {
  const clientPublicKey = new NodeRSA();
  clientPublicKey.importKey(clientPublicKeyData);
  return clientPublicKey.verify(data, signature);
}

function decrypt(data) {
  return privateKey.decrypt(encrypted, "utf8");
}

sign = privateKey.sign('abc', 'base64');
console.log(sign);

module.exports = {
  publicKeyData,
  verify,
  decrypt
};

// encrypted = publicKey.encrypt(data, 'base64', 'utf8');
// console.log(encrypted);
// decrypted = privateKey.decrypt(encrypted, 'utf8');
// console.log(decrypted);
