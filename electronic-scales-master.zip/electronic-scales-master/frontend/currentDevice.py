import tkinter as tk
import re
import time
import json
import threading
import serial
import random
import base64
import rsa
import netifaces
import logging
import os
import sys

from datetime import datetime
from time import localtime, strftime
from tkinter import BOTH, W, N, LEFT, X, RIGHT
from tkinter.ttk import Frame, Label, Entry
from logging.handlers import TimedRotatingFileHandler
from dotenv import load_dotenv

load_dotenv()

# TODO: change logger name if needed
logger = logging.getLogger('My Logger')
logger.setLevel(logging.INFO)
formatter = logging.Formatter("%(message)s")
# TODO: change out path
time_handler = TimedRotatingFileHandler('log/data.log', when='D', backupCount=30)
time_handler.setFormatter(formatter)
logger.addHandler(time_handler)

LARGE_FONT = ("Verdana", 20)

INTERFACE = os.getenv("INTERFACE")
# INTERFACE = "en0"
PRINTER_SERIAL_PORT = os.getenv("PRINTER_SERIAL_PORT")
BALANCE_SERIAL_PORT = os.getenv("BALANCE_SERIAL_PORT")
PRINTER_BAUDRATE = os.getenv("PRINTER_BAUDRATE")
BALANCE_BAUDRATE = os.getenv("BALANCE_BAUDRATE")
TEMPLATE_PATH_LARGE = os.getenv("TEMPLATE_PATH_LARGE")
TEMPLATE_PATH_SMALL = os.getenv("TEMPLATE_PATH_SMALL")

LARGE_FONT = ("Verdana", 20)

with open('rsa_key/private.pem', 'rb') as private_file:
    key_data = private_file.read()
private_key = rsa.PrivateKey.load_pkcs1(key_data, 'PEM')


weight_font = font=("Arial", 20)
normal_font = font=("Arial", 16)

current = set()

def get_mac_address():
    # TODO: change interface('wlp3s0') according to PI's interfaces
    return netifaces.ifaddresses(INTERFACE)[netifaces.AF_LINK][0]['addr']

mac_address = get_mac_address()

class Logger(object):
    def __init__(self, filename="Default"):
        self.terminal = sys.stdout
        self.filename = filename + ' ' + time.strftime('%Y-%m-%d-%H-%M-%S') + '.txt'
        self.log = open(self.filename, "a")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass

sys.stdout = Logger("system-log/stdout/log")
sys.stderr = Logger("system-log/stderr/log")

class SeaofBTCapp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.title('Quản Lý Cân Điện Tử')

        self.real_weight = tk.StringVar()
        self.real_weight.set("0")

        self.flag = tk.BooleanVar()
        self.flag.set(True)

        self.extract_flag = tk.BooleanVar()
        self.extract_flag.set(False)

        self.print_flag = tk.BooleanVar()
        self.print_flag.set(False)

        self.serial_inverted = tk.BooleanVar()
        self.serial_inverted.set(False)

        self.total_weight = tk.StringVar()
        self.total_weight.set("0")

        self.package2_weight = tk.StringVar()
        self.package2_weight.set("0")

        self.package1_weight = tk.StringVar()
        self.package1_weight.set("0")

        self.codeValue = tk.StringVar()
        self.codeValue.set("")

        self.timeValue = tk.StringVar()
        self.timeValue.set("")

        self.thread1 = threading.Thread(target=self.callApi, args=("thread 1", 0.2))
        # self.thread1 = threading.Thread(target=self.callApiDebug, args=("thread 1", 0.2))
        self.thread1.start()

        container = tk.Frame(self)

        container.pack(side="top", fill="both", expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (StartPage, PrintScreen, Settings):
            frame = F(container, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(StartPage)

    def getDatetime(self):
        self.timeValue.set(strftime("%d-%m-%Y", localtime()))
        # self.timeValue.set(strftime("%H:%M:%S %d-%m-%Y ", localtime()))

    def autoConvertCode(self, type):
        self.codeValue.set(autoUpdateCode(self.codeValue.get(), type))

    def changeExtractFlag(self):
        self.extract_flag.set(True)

    def callApi(self, nameOfThread, delay):
        print('callApi')

        while self.flag.get():
            continueFlag = True
            failParse = 0

            serialInverted = self.serial_inverted.get()
            balanceSerialPort = BALANCE_SERIAL_PORT
            if serialInverted:
                balanceSerialPort = PRINTER_SERIAL_PORT

            print(balanceSerialPort)
            ser = serial.Serial(balanceSerialPort, BALANCE_BAUDRATE, timeout = 0.5)

            while continueFlag:
                try:
                    readOut = ser.readline().decode("ascii")
                    temp_weight = 0.0

                    if len(readOut) == 20:
                        print("Data true")
                        temp_weight = float(data[7:-4].replace(" ", ""))
                        failParse = 0
                    else:
                        failParse = failParse + 1

                    self.real_weight.set(temp_weight)

                    if (self.extract_flag.get() == False):
                        self.total_weight.set(temp_weight)
                    elif (self.print_flag.get() == False):
                        self.package1_weight.set(temp_weight)
                        self.package2_weight.set(float(self.total_weight.get()) - float(self.package1_weight.get()))

                except:
                    pass

                ser.flush()

                if (failParse > 10):
                    continueFlag = False

                print(failParse)
            ser.close()

            self.serial_inverted.set(not self.serial_inverted.get())

    def callApiDebug(self, nameOfThread, delay):
        print("call api debug")
        while self.flag.get():
            try:
                time.sleep(1)
                temp_weight = float(random.randint(0, 1000))
                self.real_weight.set(temp_weight)
                if (self.extract_flag.get() == False):
                    self.total_weight.set(temp_weight)
                else:
                    self.package2_weight.set(temp_weight)
                    self.package1_weight.set(float(self.total_weight.get()) - float(self.package2_weight.get()))
            except:
                pass

    def detectScale(self):
        self.serial_inverted.set(not self.serial_inverted.get())
        self.changeExtractStatus(False)
        self.changePrintStatus(False)
        self.start_callapi_thread("thread 1", 1)

    def changeExtractStatus(self, value):
        self.extract_flag.set(value)

    def changePrintStatus(self, value):
        self.print_flag.set(value)

    def resetWeights(self):
        self.package1_weight.set("0")
        self.package2_weight.set("0")

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

    def start_callapi_thread(self, name, delay):
        self.flag.set(False)
        time.sleep(1)
        self.flag.set(True)
        self.thread1 = threading.Thread(target=self.callApi, args=(name, 0.2))
        self.thread1.start()

    def backtoStartPage(self):
        self.changeExtractStatus(False)
        self.changePrintStatus(False)
        self.resetWeights()
        self.show_frame(StartPage)


class StartPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        self.pack(fill=BOTH, expand=True)

        # title screen
        frameTitle = Frame(self)
        frameTitle.pack(fill=X)

        lblTitle = tk.Label(frameTitle, text="Cân", font=("Courier", 30), bg="green", fg="white")
        lblTitle.pack(anchor=W, padx=5, pady=5)

        # Weight figure
        frameTotalWeight = Frame(self)
        frameTotalWeight.pack(fill=X)

        lblTotalWeight = tk.Label(frameTotalWeight, textvariable=controller.real_weight, font=("Courier", 40), fg="blue")
        lblTotalWeight.pack(anchor=N)

        # layer sum weight
        frame1 = Frame(self)
        frame1.pack(fill=X)

        lbl1 = Label(frame1, text="Tổng số cân", width=30, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        lblWeightSum = Label(frame1, textvariable=controller.total_weight, width=30, font=weight_font)
        lblWeightSum.configure(anchor="center")
        lblWeightSum.pack(side=LEFT, pady=1, expand=True)

        # layer 1 weight
        frame2 = Frame(self)
        frame2.pack(fill=X)

        lbl2 = Label(frame2, text="Số cân kiện 1", width=30, font=weight_font)
        lbl2.configure(anchor="center")
        lbl2.pack(side=LEFT, pady=1, expand=True)

        lblWeight1 = Label(frame2, textvariable=controller.package1_weight, width=30, font=weight_font)
        lblWeight1.configure(anchor="center")
        lblWeight1.pack(side=LEFT, pady=1, expand=True)

        # layer 2 weight
        frame3 = Frame(self)
        frame3.pack(fill=X)

        lbl3 = Label(frame3, text="Số cân kiện 2", width=30, font=weight_font)
        lbl3.configure(anchor="center")
        lbl3.pack(side=LEFT, pady=1, expand=True)

        lblWeight2 = Label(frame3, textvariable=controller.package2_weight, width=30, font=weight_font)
        lblWeight2.configure(anchor="center")
        lblWeight2.pack(side=LEFT, pady=1, expand=True)

        controller.getDatetime()
        # button container
        container = Frame(self)
        container.pack(fill=BOTH, expand=True)

        frame4 = Frame(container)
        frame4.pack(fill=BOTH)

        btnExtract = tk.Button(frame4, fg="green", text="  Tách  ", padx=30, pady=10, font=weight_font, command=lambda: controller.changeExtractStatus(True))
        btnExtract.pack(side=LEFT, expand=True, padx=20, pady=20 )

        btnOk = tk.Button(frame4, text="  Print  ", padx=30, pady=10, font=weight_font, command=lambda: {
            controller.changePrintStatus(True),
            getDataFromTxt("material"),
            controller.show_frame(PrintScreen),

        })
        btnOk.pack(side=LEFT, expand=True, padx=20, pady=20)

        # frame5 = Frame(container)
        # frame5.pack(fill=BOTH)

        # btnDetect = tk.Button(frame5, fg="red", text="  Detect  ", padx=30, pady=10, font=weight_font, command=lambda: {
        #     controller.detectScale()
        # })
        # btnDetect.pack(side=LEFT, expand=True, padx=20, pady=20)

        btnClear = tk.Button(frame4, fg="red", text="   Xóa  ", padx=30, pady=10, font=weight_font, command=lambda: {
            controller.changeExtractStatus(False),
            controller.changePrintStatus(False),
            controller.resetWeights()
        })
        btnClear.pack(side=LEFT, expand=True, padx=20, pady=20)


class PrintScreen(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        # title screen
        frameTitle = Frame(self)
        frameTitle.pack(fill=BOTH)

        lblTitle = tk.Label(frameTitle, text="Chi tiết temp", font=("Courier", 30), bg="green", fg="white")
        lblTitle.pack(anchor=W, padx=5, pady=5)

        self.package1Bool = tk.BooleanVar()
        self.package1Bool.set(False)

        self.package2Bool = tk.BooleanVar()
        self.package2Bool.set(False)

        # layer cate
        frame1 = Frame(self)
        frame1.pack(fill=X)

        lbl1 = Label(frame1, text="Thành phẩm", width=30, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        self.entry_character = tk.Entry(frame1, font=weight_font)
        self.entry_character.insert(tk.END, getDataFromTxt("material"))
        self.entry_character.pack(side=LEFT, pady=1, expand=True)

        # layer code
        frame2 = Frame(self)
        frame2.pack(fill=X)

        lbl1 = Label(frame2, text="Mã số", width=30, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        self.entry_code = tk.Entry(frame2, font=weight_font, textvariable=controller.codeValue)
        self.entry_code.pack(side=LEFT, pady=1, expand=True)

        # layer time
        frame3 = Frame(self)
        frame3.pack(fill=X)

        lbl1 = Label(frame3, text="Thời gian", width=30, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        self.entry_time = tk.Entry(frame3, font=weight_font)
        self.entry_time = tk.Entry(frame3, font=weight_font, textvariable=controller.timeValue)
        self.entry_time.pack(side=LEFT, pady=1, expand=True)

        # layer panel
        frame4 = Frame(self)
        frame4.pack(fill=X)

        lbl1 = Label(frame4, text="Số thanh", width=30, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        self.entry_panel = tk.Entry(frame4, font=weight_font)
        self.entry_panel.insert(tk.END, "93")
        self.entry_panel.pack(side=LEFT, pady=1, expand=True)

        # layer weight 1
        frame5 = Frame(self)
        frame5.pack(fill=X)

        lbl1 = Label(frame5, text="Số cân kiện 1", width=10, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        self.weight1 = Label(frame5, font=weight_font, textvariable=controller.package1_weight)
        self.weight1.pack(side=LEFT, pady=1, expand=True)

        # layer weight 2
        frame6 = Frame(self)
        frame6.pack(fill=X)

        lbl1 = Label(frame6, text="Số cân kiện 2", width=10, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.pack(side=LEFT, pady=1, expand=True, padx=5, fill=X)

        self.weight2 = Label(frame6, font=weight_font, textvariable=controller.package2_weight)
        self.weight2.pack(side=LEFT, pady=1, expand=True)

        # button container
        container = Frame(self)
        container.pack(fill=BOTH, expand=True)

        frame4 = Frame(container)
        frame4.pack(fill=X, padx=(50, 1), pady=(5, 0))

        btnExtract = tk.Button(frame4, fg="green", text="In kiện 1", padx=30, pady=5, font=weight_font, command=lambda: {
            self.confirmPrint(controller, 1)
        })
        btnExtract.pack(side=LEFT, expand=True, padx=1, pady=5)

        btnOk = tk.Button(frame4, fg="green", text="In kiện 2", padx=30, pady=5, font=weight_font, command=lambda: {
            # show print confirm and save last data to txt
            self.confirmPrint(controller, 2)
        })
        btnOk.pack(side=LEFT, expand=True, padx=1, pady=5)

        frame5 = Frame(container)
        frame5.pack(fill=X, padx=(50, 1), pady=(0, 0))

        btnClear = tk.Button(frame5, text="Quay lại", padx=30, pady=2, font=weight_font, command=lambda: {
            self.package1Bool.set(False),
            self.package2Bool.set(False),
            controller.backtoStartPage()
        })
        btnClear.pack(side=LEFT, expand=True, padx=20, pady=5)

        btnOk = tk.Button(frame5, text="   Lưu    ", padx=30, pady=2, font=weight_font, command=lambda: {
            saveData("material", self.entry_character.get()),

            self.write2Log(controller),

            # self.increaseCode(controller),

            self.package1Bool.set(False),
            self.package2Bool.set(False),
            controller.backtoStartPage()
        })
        btnOk.pack(side=LEFT, expand=True, padx=20, pady=5)

    def write2Log(self, controller):
        print('write2Log')
        if (self.package1Bool.get() == False and int(float(controller.package1_weight.get())) > 0):
            writeLog(self.entry_character.get(), "", str(self.entry_panel.get()),
                     str(controller.package1_weight.get()),
                     self.entry_time.get(), self.entry_code.get(), "")
            controller.autoConvertCode(1)

        if (self.package2Bool.get() == False and int(float(controller.package2_weight.get())) > 0):
            writeLog(self.entry_character.get(), "", str(self.entry_panel.get()),
                     str(controller.package2_weight.get()),
                     self.entry_time.get(), self.entry_code.get(), "")
            controller.autoConvertCode(1)

    def increaseCode(self, controller):
        if (self.package1Bool.get() == False and self.package2Bool.get() == False):
            controller.autoConvertCode(3)
        if (self.package1Bool.get() == True and self.package2Bool.get() == False):
            controller.autoConvertCode(1)
        elif (self.package1Bool.get() == False and self.package2Bool.get() == True):
            controller.autoConvertCode(1)


    def confirmPrint(self, controller, type):
        if type == 1:
            weight_to_save = controller.package1_weight.get()
            self.package1Bool.set(True)
        elif type == 2:
            weight_to_save = controller.package2_weight.get()
            self.package2Bool.set(True)

        #if int(float(weight_to_save)) <= 0:
        #    print('weight_to_save == 0')
        #    return

        serialInverted = controller.serial_inverted.get()

        writeLog(self.entry_character.get(), "", str(self.entry_panel.get()), str(weight_to_save), self.entry_time.get(), self.entry_code.get(), "")

        template = TEMPLATE_PATH_SMALL
        printTem(product=self.entry_character.get(),
                    barNumber=str(self.entry_panel.get()),
                    weight=str(weight_to_save),
                    productDate=self.entry_time.get(),
                    code=self.entry_code.get(),
                    template=template,
                    serialInverted=serialInverted)

        # auto increase
        controller.autoConvertCode(type)
        saveData("material", self.entry_character.get())


class Settings(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        # title screen
        frameTitle = Frame(self)
        frameTitle.pack(fill=BOTH)

        lblTitle = tk.Label(frameTitle, text="Cài đặt", font=("Courier", 30), bg="green", fg="white")
        lblTitle.pack(anchor=W, padx=5, pady=5)

        frame1 = Frame(self)
        frame1.pack(fill=X,)

        lbl1 = Label(frame1, text="Thêm thành phẩm mới", width=30, font=weight_font)
        lbl1.configure(anchor="center")
        lbl1.grid(row=0, column=0, pady=10,)

        catEntry = Entry(frame1, font=weight_font)
        catEntry.grid(row=0, column=1, sticky="nsew")

        addBtn = tk.Button(frame1, text="Thêm", font=weight_font)
        addBtn.grid(row=0, column=2, sticky="nsew")

        lbl2 = Label(frame1, text="Danh sách thành phẩm", width=16, font=weight_font)
        lbl2.configure(anchor="center")
        lbl2.grid(row=1, column=0, sticky="nsew", pady=20)

        frame2 = Frame(self)
        frame2.pack(fill=BOTH, expand=True)

        lbl3 = Label(frame2, text="1. ABC", width=50, font=normal_font)
        lbl3.configure(anchor="center")
        lbl3.grid(row=0, column=0, pady=10, )

        lbl3 = Label(frame2, text="2. XYZ", width=50, font=normal_font)
        lbl3.configure(anchor="center")
        lbl3.grid(row=1, column=0, pady=10, )

        frame3 = Frame(self)
        frame3.pack(fill=BOTH, expand=True)

        backBtn = tk.Button(frame3, text="OK", font=weight_font, width=12, pady=5, command=lambda: {
            controller.show_frame(StartPage)
        })
        backBtn.pack(side="top")

        # frame1 configure column
        frame1.columnconfigure(0, weight=2, uniform='third')
        frame1.columnconfigure(1, weight=5, uniform='third')
        frame1.columnconfigure(2, weight=1, uniform='third')

def parseWeight(data):
    if len(data) == 20:
        print("Data true")
        return float(data[7:-4].replace(" ", ""))

    print("Data fail")
    return 0.0


def printTem(product, barNumber, weight, productDate, code, template, serialInverted):
    data = readTemplate(template)
    # 0 - Màu xanh, 1 - Màu vàng
    # colorName = 'Xanh'
    # if (color == 1):
    #     colorName = 'Vang'
    qrCode = 'http://vanloialuminum.com.vn'

    data = data.replace("{{product}}", product)
    data = data.replace("{{barNumber}}", barNumber)
    data = data.replace("{{weight}}", weight)
    data = data.replace("{{productDate}}", productDate)
    data = data.replace("{{code}}", code)
    data = data.replace("{{qrCode}}", qrCode)
    data = data.replace("\n", "\r\n")
    sendToPrinter(data, serialInverted)
    return

def to_json_string(obj):
    return json.dumps(obj, ensure_ascii=False)

def convertType(type, color):
    return 2 * type + color

def writeLog(product, color, barNumber, weight, productDate, code, type):
    date = strftime("%H:%M:%S %d-%m-%Y ", localtime())
    arr = code.split()
    batchNo = ""
    order = ""
    if len(arr) == 2:
        batchNo = arr[0]
        order = arr[1]

    hms = date.split()
    convertDate = str(hms[0]) + " " + str(productDate)
    print("date", convertDate)
    obj = {
        "time": int(convertDatetimeToEpoch(convertDate)),
        "material": product,
        "numMaterials": int(barNumber),
        "serialNo": code,
        "weight": int(float(weight)),
        "type": -1,
        "batchNo": batchNo,
        "order": order
    }

    data = to_json_string(obj)
    signature = sign(data)
    print(mac_address)
    log = {"data": data, "macAddress": mac_address, "sign": signature}
    logger.info(to_json_string(log))


def readTemplate(templatePath):
    tFile = open(templatePath, "r")
    template = tFile.read()
    tFile.close()
    return template


def sendToPrinter(data, serialInverted):
    print("sendToPrinter")
    printerSerialPort = PRINTER_SERIAL_PORT
    if serialInverted:
        printerSerialPort = BALANCE_SERIAL_PORT
    print("printerSerialPort")
    print(printerSerialPort)
    ser = serial.Serial(printerSerialPort, PRINTER_BAUDRATE, timeout=1)
    print(data.encode("utf-8"))
    ser.write(str(data).encode("utf-8"))
    ser.close()
    return


def autoUpdateCode(data, type):
    if len(data) > 0:
        arr = data.split()
        if len(arr) > 1:
            if type == 0:
                amount = 0
            elif type == 1 or type == 2:
                amount = 1
            else:
                amount = 2
            temp = int(arr[1]) + amount
            if temp < 10:
                tail = " 0" + str(temp)
            else:
                tail = " " + str(temp)
            result = arr[0] + tail
            print(result)
            return result

    return data


def saveData(source, data):
    with open(source + ".log", "w") as f:
        f.write(data)
        f.close()

def getDataFromTxt(source):
    with open(source + ".log", "r") as f:
        data = f.read()
        f.close()
        return data

def sign(data):
    signature = rsa.sign(data.encode(), private_key, 'SHA-256')
    return base64.b64encode(signature).decode("utf-8")

def convertDatetimeToEpoch(date):
    # 00: 37:01 27 - 07 - 2019
    array = re.findall(r"[\w']+", date)
    print(array)
    temp_array = []

    for i in reversed(array):
        temp_array.append(int(i))

    print(datetime(temp_array[0], temp_array[1], temp_array[2], temp_array[5], temp_array[4], temp_array[3]).timestamp())
    return datetime(temp_array[0], temp_array[1], temp_array[2], temp_array[5], temp_array[4], temp_array[3]).timestamp()

app = SeaofBTCapp()
# app.bind('<q>', executeQuit())
w = app.winfo_screenwidth()
h = app.winfo_screenheight()
app.geometry('%dx%d+%d+%d' %(w, h, 0, 0))
app.title="Quản lý máy in"
app.mainloop()
